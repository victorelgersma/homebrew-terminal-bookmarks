# Remove -c 

the -c command is rarely useful and just adds clutter. remove it. 