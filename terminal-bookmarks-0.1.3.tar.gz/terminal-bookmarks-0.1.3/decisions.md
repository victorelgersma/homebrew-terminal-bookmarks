# Decisions made

Sat may 24
- went with grep over rg for sake of unix compatibility and minimal dependencies